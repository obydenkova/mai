#include <iostream>
#include <sstream>
#include <fstream>

#include "BigInt.h"

class Calculator {
public:
    static std::string Calculate(const BigInt& lhs, const BigInt& rhs, char operation) {
        try {
            if (operation == '^') {
                return(lhs ^ rhs).ToString();
            }
            if (operation == '+') {
                return(lhs + rhs).ToString();
            }
            if (operation == '-') {
                return(lhs - rhs).ToString();
            }
            if (operation == '*') {
                return(lhs * rhs).ToString();
            }
            if (operation == '/') {
                return(lhs / rhs).ToString();
            }
            if (operation == '>') {
                return (lhs > rhs ? "true" : "false");
            }
            if (operation == '=') {
                return (lhs == rhs ? "true" : "false");
            }
            if (operation == '<') {
                return (lhs < rhs ? "true" : "false");
            } else {
                return "Wrong operation";
            }
        } catch (std::logic_error&) {
            return "Error";
        }
    }
};

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    char operation;
    std::string firstNumber, secondNumber;
    while (std::cin >> firstNumber >> secondNumber >> operation) {
        std::cout << Calculator::Calculate(BigInt(firstNumber), BigInt(secondNumber), operation) << "\n";
    }
    return 0;
}

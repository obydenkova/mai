#pragma once


#include <vector>
#include <string>
#include <cmath>
#include <type_traits>
#include <algorithm>

class BigInt {
public:

    BigInt();
    explicit BigInt(const std::string& str);

    template <typename T>
    explicit BigInt(T number,  typename std::enable_if<std::is_integral<T>::value>::type* = 0);

    friend std::ostream& operator << (std::ostream& os, const BigInt& number);
    friend std::istream& operator >> (std::istream& is, BigInt& number);

    BigInt operator + (const BigInt& other) const;
    BigInt operator - (const BigInt& other) const;


    BigInt operator * (const BigInt& other) const;
    BigInt operator * (long long other) const;
    BigInt operator / (const BigInt& other) const;
    BigInt operator / (long long other) const;

    BigInt operator ^ (BigInt other) const;


    bool operator < (const BigInt& other) const;
    bool operator > (const BigInt& other) const;
    bool operator == (const BigInt& other) const;
    bool operator != (const BigInt& other) const;

    std::string ToString() const;

private:

    BigInt(std::vector<int> v);

    void DeleteZeros();
    static int Compare(const BigInt& lhs, const BigInt& rhs);
    static int FindDiv(const BigInt &left, const BigInt &right);


    std::vector<int> data;

    static const size_t basePower = 6;
    static const size_t base = std::pow(10, basePower);

};

#include "BigInt.hpp"
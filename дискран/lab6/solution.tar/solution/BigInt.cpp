

#include <iostream>
#include <iomanip>
#include <sstream>
#include <algorithm>
#include "BigInt.h"



BigInt::BigInt()
: data(1, 0) {}


BigInt::BigInt(const std::string &str) {
    const size_t shift = basePower;
    size_t index = str.size();
    while (true) {
        int cur;
        if (index > shift) {
            cur = std::stoi(str.substr(index - shift, shift));
            index -= shift;
            data.push_back(cur);
        } else {
            cur = std::stoi(str.substr(0, index));
            data.push_back(cur);
            break;
        }
    }
    DeleteZeros();
}

BigInt::BigInt(std::vector<int> v)
: data(std::move(v)) {}

std::istream& operator >> (std::istream& is, BigInt& number) {
    std::string temp;
    is >> temp;
    number = BigInt(temp);
    return is;
}

std::ostream& operator << (std::ostream& os, const BigInt& num) {
    for (std::vector<int>::const_reverse_iterator it = num.data.crbegin(); it != num.data.crend(); ++it) {
        if (it == num.data.crbegin()) {
            os << *it;
        } else {
            os << std::setw(BigInt::basePower) << std::setfill('0') << *it;
        }
    }
    return os;
}

BigInt BigInt::operator + (const BigInt& other) const {
    BigInt result;
    result.data.resize(std::max(data.size(), other.data.size()) + 1);
    int extra = 0;
    for (int i = 0; i < std::max(data.size(), other.data.size()) || extra; ++i) {
        int f_cur = i < (int) data.size() ? data[i] : 0;
        int s_cur = i < (int) other.data.size() ? other.data[i] : 0;
        result.data[i] = (f_cur + s_cur + extra);
        extra = result.data[i] >= base;
        if (extra)
            result.data[i] -= base;
    }
    result.DeleteZeros();
    return result;
}

BigInt BigInt::operator - (const BigInt& other) const {
    if (other > *this) {
        throw std::logic_error("cant decrease bigger number");
    }
    BigInt result;
    result.data.resize(data.size(), 0);
    int extra = 0;
    for (size_t i = 0; i < std::max(data.size(), other.data.size()); ++i) {
        int fInt = (i < data.size() ? data[i] : 0);
        int sInt = (i < other.data.size() ? other.data[i] : 0);
        if (fInt - extra >= sInt) {
            result.data[i] = fInt - extra - sInt;
            extra = 0;
        } else {
            result.data[i] = base + fInt - extra - sInt;
            extra = 1;
        }
    }
    result.DeleteZeros();
    return result;
}


BigInt BigInt::operator * (const BigInt& other) const {
    BigInt result;
    result.data.resize(data.size() + other.data.size());
    for (size_t i = 0; i < data.size(); ++i) {
        long long carry = 0;
        for (size_t j = 0; j < other.data.size() || carry != 0; ++j) {
            long long current = result.data[i + j]
                                + static_cast<long long>(data[i])
                    * static_cast<long long>(j < other.data.size() ? other.data[j] : 0) + carry;
            result.data[i + j] = current % base;
            carry = current / static_cast<int>(base);
        }
    }
    result.DeleteZeros();
    return result;
}

BigInt BigInt::operator * (long long other) const {
    BigInt result;
    result.data.resize(data.size() + 1);
    int carry = 0;
    for (size_t i = 0; i < data.size() || carry; ++i) {
        long long cur = carry + (i < data.size() ? data[i] : 0) * other;
        result.data[i] = int (cur % base);
        carry = int (cur / base);
    }
    result.DeleteZeros();
    return result;
}


BigInt BigInt::operator / (const BigInt& other) const {
    if (other == BigInt(0)) {
        throw std::logic_error("division by zero");
    }
    if (*this == BigInt(0)) {
        return BigInt(0);
    }
    if (*this < other) {
        return BigInt(0);
    }

    if (other < BigInt(base)) {
        return *this / other.data.front();
    }

    long long n = other.data.size();
    long long m = data.size() - other.data.size();

    long long d = (base / (other.data.back() + 1));
    size_t oldSize = data.size();
    BigInt u = *this * d;
    BigInt v = other * d;
    if (u.data.size() == oldSize) {
        u.data.push_back(0);
    }
    BigInt result;
    for (size_t j = m; j + 1 > 0; --j) {
        long long qHat = (u.data[j + n] * base + u.data[j + n - 1]) / v.data[n - 1];
        long long rHat = (u.data[j + n] * base + u.data[j + n - 1]) % v.data[n - 1];
        if (qHat == base || qHat * v.data[n - 2] > base * rHat + u.data[j + n - 2]) {
            qHat--;
            rHat += v.data[n - 1];
        }
        if (rHat < base && (qHat == base || qHat * v.data[n - 2] > base * rHat + u.data[j + n - 2])) {
            qHat--;
            rHat += v.data[n - 1];
        }
        BigInt uTemp(std::vector<int>(u.data.begin() + j, u.data.begin() + j + n + 1));
        BigInt vTemp = v * qHat;
        bool extraRareCase = false;
        if (uTemp < vTemp) {
            BigInt tempResult  = (BigInt(base) ^ BigInt(n + 1)) - (vTemp - uTemp);
            while (tempResult.data.size() != n + 1) {
                tempResult.data.push_back(0);
            }
            std::copy(tempResult.data.begin(), tempResult.data.end(), u.data.begin() + j);
            extraRareCase = true;
        } else {
            BigInt tempResult  = uTemp - vTemp;
            while (tempResult.data.size() != n + 1) {
                tempResult.data.push_back(0);
            }
            std::copy(tempResult.data.begin(), tempResult.data.end(), u.data.begin() + j);
        }
        result.data.push_back(qHat);
        if (extraRareCase) {
            result.data.back()--;
            BigInt temp(std::vector<int>(u.data.begin() + j, u.data.begin() + j + n + 1));
            temp = temp + v;
            temp.data.pop_back();
            std::copy(temp.data.begin(), temp.data.end(), u.data.begin() + j);
        }
    }
    std::reverse(result.data.begin(), result.data.end());
    result.DeleteZeros();
    return result;
}

BigInt BigInt::operator / (long long other) const {
    if (other == 0) {
        throw std::logic_error("division by zero");
    }
    if (*this < BigInt(other)) {
        return BigInt(0);
    }
    BigInt result;
    result.data.resize(data.size());
    int carry = 0;
    for (size_t i = data.size() - 1; i + 1 > 0; --i) {
        long long cur = data[i] + carry * base;
        result.data[i] = int (cur / other);
        carry = int (cur % other);
    }
    result.DeleteZeros();
    return result;
}

BigInt BigInt::operator ^ (BigInt other) const {
    BigInt result(1);
    BigInt copy = *this;
    if (*this == BigInt(1)) {
        return BigInt(1);
    }
    if (*this == BigInt(0)) {
        if (other == BigInt(0)) {
            throw std::logic_error("0 powered by 0");
        }
        return BigInt(0);
    }
    unsigned long long power = 0;
    bool casted = true;
    try {
        std::stringstream os;
        os << other;
        power = std::stoull(os.str());
    } catch (...) {
        casted = false;
    }
    if (casted) {
        while (power != 0) {
            if (power % 2 == 0) {
                copy = copy * copy;
                power = power / 2;
            } else {
                result = result * copy;
                power--;
            }
        }
        return result;
    } else {
        throw std::runtime_error("TODO :)");
    }

}

bool BigInt::operator < (const BigInt& other) const {
    return BigInt::Compare(*this, other) == -1;
}

bool BigInt::operator > (const BigInt& other) const {
    return BigInt::Compare(*this, other) == 1;
}

bool BigInt::operator == (const BigInt& other) const {
    return BigInt::Compare(*this, other) == 0;
}

bool BigInt::operator != (const BigInt& other) const {
    return BigInt::Compare(*this, other) != 0;
}


int BigInt::Compare(const BigInt &lhs, const BigInt &rhs) {
    if (lhs.data.size() != rhs.data.size()) {
        return lhs.data.size() > rhs.data.size() ? 1 : -1;
    }
    std::vector<int>::const_reverse_iterator lhsIt = lhs.data.crbegin();
    std::vector<int>::const_reverse_iterator rhsIt = rhs.data.crbegin();
    while (lhsIt != lhs.data.crend()) {
        if (*lhsIt != *rhsIt) {
            return *lhsIt > *rhsIt ? 1 : -1;
        }
        lhsIt++;
        rhsIt++;
    }
    return 0;
}


std::string BigInt::ToString() const {
    std::string result;
    for (std::vector<int>::const_reverse_iterator it = data.crbegin(); it != data.crend(); ++it) {
        if (it == data.crbegin()) {
            result += std::to_string(*it);
        } else {
            std::string radix = std::to_string(*it);
            result += (radix.size() == basePower ? radix : std::string(basePower - radix.size(), '0') + radix);
        }
    }
    return result;
}

void BigInt::DeleteZeros() {
    while (data.size() > 1 && data.back() == 0) {
        data.pop_back();
    }
    if (data.empty()){
        data.push_back(0);
    }
}

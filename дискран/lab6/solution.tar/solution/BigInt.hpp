#pragma once

template<typename T>
BigInt::BigInt(T number, typename std::enable_if<std::is_integral<T>::value>::type *) {
    while (number != 0) {
        data.push_back(number % base);
        number /= base;
    }
    DeleteZeros();
}

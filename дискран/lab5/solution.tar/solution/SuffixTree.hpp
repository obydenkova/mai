#pragma once

#include "SuffixTree.h"

template <typename Func>
void SuffixTree::DFS (SuffixNode* node, Func f) {
    f(node);
    for (std::pair<char, SuffixNode::ArcInfo> elem : node->links_) {
        DFS(elem.second.link_, f);
    }
}